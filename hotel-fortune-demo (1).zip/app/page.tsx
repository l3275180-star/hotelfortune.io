'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Menu, X, Star, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const rooms = [
    {
      id: 1,
      title: 'Deluxe Room',
      price: '₹8,500',
      image: '/deluxe-room.png',
      features: ['42" Flat Screen TV', 'Premium Bedding', 'City View', 'Free WiFi']
    },
    {
      id: 2,
      title: 'Executive Suite',
      price: '₹12,500',
      image: '/deluxe-room.png',
      features: ['Living Area', 'Workspace', 'Premium Amenities', 'Concierge']
    },
    {
      id: 3,
      title: 'Presidential Suite',
      price: '₹18,000',
      image: '/deluxe-room.png',
      features: ['2 Bedrooms', 'Jacuzzi', 'Personal Butler', 'Private Lounge']
    }
  ]

  const amenities = [
    {
      title: 'Fine Dining Restaurant',
      icon: '🍽️',
      description: 'Experience world-class cuisine with international and Indian specialties'
    },
    {
      title: 'Luxury Spa',
      icon: '🧖',
      description: 'Rejuvenate with our premium wellness and spa treatments'
    },
    {
      title: 'Swimming Pool',
      icon: '🏊',
      description: 'Olympic-size pool with stunning city views'
    },
    {
      title: 'Fitness Center',
      icon: '💪',
      description: 'State-of-the-art gym with personal training services'
    },
    {
      title: 'Business Center',
      icon: '💼',
      description: 'Fully equipped conference and meeting facilities'
    },
    {
      title: '24/7 Concierge',
      icon: '🔔',
      description: 'Round-the-clock personalized service and assistance'
    }
  ]

  const testimonials = [
    {
      name: 'Rajesh Kumar',
      role: 'Business Traveler',
      text: 'Exceptional service and stunning accommodations. Hotel Fortune is my preferred choice in Patna.',
      rating: 5
    },
    {
      name: 'Priya Sharma',
      role: 'Leisure Guest',
      text: 'The spa and dining experience was absolutely incredible. Highly recommend!',
      rating: 5
    },
    {
      name: 'Amit Patel',
      role: 'Corporate Guest',
      text: 'Perfect venue for our corporate retreat. Professional staff and excellent facilities.',
      rating: 5
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center text-white font-bold text-lg">
                🏨
              </div>
              <span className="text-xl font-semibold text-primary hidden sm:block">Hotel Fortune</span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex gap-8">
              <a href="#rooms" className="text-foreground hover:text-primary transition">Rooms</a>
              <a href="#amenities" className="text-foreground hover:text-primary transition">Amenities</a>
              <a href="#gallery" className="text-foreground hover:text-primary transition">Gallery</a>
              <a href="#contact" className="text-foreground hover:text-primary transition">Contact</a>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden pb-4 flex flex-col gap-4">
              <a href="#rooms" className="text-foreground hover:text-primary transition">Rooms</a>
              <a href="#amenities" className="text-foreground hover:text-primary transition">Amenities</a>
              <a href="#gallery" className="text-foreground hover:text-primary transition">Gallery</a>
              <a href="#contact" className="text-foreground hover:text-primary transition">Contact</a>
              <Button className="w-full">Book Now</Button>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen md:h-[600px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/hotel-hero.png"
            alt="Hotel Fortune"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-black/40" />
        </div>

        <div className="relative z-10 text-center text-white px-4 max-w-2xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 text-balance">
            Welcome to Hotel Fortune
          </h1>
          <p className="text-lg md:text-2xl mb-8 text-balance">
            Experience Luxury in the Heart of Patna
          </p>
          <Button className="bg-primary hover:bg-accent text-white px-8 py-3 text-lg">
            Book Your Stay
          </Button>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
                Discover Timeless Elegance
              </h2>
              <p className="text-foreground/70 mb-4 text-lg leading-relaxed">
                Hotel Fortune stands as Patna&apos;s premier luxury destination, blending contemporary comfort with the rich heritage of this historic city. Our commitment to excellence ensures every moment of your stay is unforgettable.
              </p>
              <p className="text-foreground/70 mb-8 text-lg leading-relaxed">
                With world-class amenities, impeccable service, and an ideal location, we cater to discerning travelers seeking the finest hospitality experience.
              </p>
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-3">
                  <div className="text-primary text-2xl">⭐</div>
                  <span className="font-semibold text-foreground">5-Star Luxury</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-primary text-2xl">🏆</div>
                  <span className="font-semibold text-foreground">Award Winning</span>
                </div>
              </div>
            </div>
            <div className="relative h-96 md:h-full rounded-lg overflow-hidden shadow-xl">
              <Image
                src="/hotel-hero.png"
                alt="Hotel Interior"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Rooms Section */}
      <section id="rooms" className="py-16 md:py-24 bg-secondary/5">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Our Exquisite Rooms
            </h2>
            <p className="text-foreground/60 text-lg max-w-2xl mx-auto">
              Choose from our carefully curated selection of luxurious accommodations
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {rooms.map((room) => (
              <div key={room.id} className="bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition">
                <div className="relative h-64">
                  <Image
                    src={room.image}
                    alt={room.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold text-foreground mb-2">{room.title}</h3>
                  <p className="text-primary text-xl font-semibold mb-4">from {room.price}/night</p>
                  <ul className="space-y-3 mb-6">
                    {room.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-3 text-foreground/70">
                        <Check className="w-5 h-5 text-primary" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Button className="w-full bg-primary hover:bg-accent text-white">
                    View Details
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Amenities Section */}
      <section id="amenities" className="py-16 md:py-24 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              World-Class Amenities
            </h2>
            <p className="text-foreground/60 text-lg max-w-2xl mx-auto">
              Enjoy premium facilities designed for your comfort and convenience
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {amenities.map((amenity, idx) => (
              <div key={idx} className="p-8 bg-secondary/5 rounded-lg hover:shadow-lg transition">
                <div className="text-5xl mb-4">{amenity.icon}</div>
                <h3 className="text-xl font-bold text-foreground mb-3">{amenity.title}</h3>
                <p className="text-foreground/60 leading-relaxed">{amenity.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-16 md:py-24 bg-secondary/5">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Experience Gallery
            </h2>
            <p className="text-foreground/60 text-lg max-w-2xl mx-auto">
              Explore the beauty and sophistication of Hotel Fortune
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="relative h-96 rounded-lg overflow-hidden shadow-lg group">
              <Image src="/restaurant.png" alt="Restaurant" fill className="object-cover group-hover:scale-105 transition" />
              <div className="absolute inset-0 bg-black/30 flex items-end p-6">
                <h3 className="text-white text-2xl font-bold">Fine Dining</h3>
              </div>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-lg group">
              <Image src="/pool.png" alt="Pool" fill className="object-cover group-hover:scale-105 transition" />
              <div className="absolute inset-0 bg-black/30 flex items-end p-6">
                <h3 className="text-white text-2xl font-bold">Swimming Pool</h3>
              </div>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-lg group">
              <Image src="/spa.png" alt="Spa" fill className="object-cover group-hover:scale-105 transition" />
              <div className="absolute inset-0 bg-black/30 flex items-end p-6">
                <h3 className="text-white text-2xl font-bold">Luxury Spa</h3>
              </div>
            </div>
            <div className="relative h-96 rounded-lg overflow-hidden shadow-lg group">
              <Image src="/deluxe-room.png" alt="Room" fill className="object-cover group-hover:scale-105 transition" />
              <div className="absolute inset-0 bg-black/30 flex items-end p-6">
                <h3 className="text-white text-2xl font-bold">Guest Rooms</h3>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 md:py-24 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Guest Reviews
            </h2>
            <p className="text-foreground/60 text-lg max-w-2xl mx-auto">
              What our guests are saying about their stay
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, idx) => (
              <div key={idx} className="bg-secondary/5 p-8 rounded-lg">
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-foreground/70 mb-6 leading-relaxed italic">&quot;{testimonial.text}&quot;</p>
                <div>
                  <p className="font-bold text-foreground">{testimonial.name}</p>
                  <p className="text-foreground/60 text-sm">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 md:py-24 bg-primary text-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
            <p className="text-white/80 text-lg max-w-2xl mx-auto">
              Ready to book your perfect stay?
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-white/10 p-8 rounded-lg text-center">
              <div className="text-4xl mb-4">📍</div>
              <h3 className="text-xl font-bold mb-2">Address</h3>
              <p className="text-white/80">
                Ashoka Raj Path,<br />
                Fraser Road, Patna<br />
                Bihar 800001
              </p>
            </div>

            <div className="bg-white/10 p-8 rounded-lg text-center">
              <div className="text-4xl mb-4">📞</div>
              <h3 className="text-xl font-bold mb-2">Phone</h3>
              <p className="text-white/80">
                <a href="tel:+916122254567" className="hover:text-white transition">+91-612-225-4567</a><br />
                <a href="tel:+916122254500" className="hover:text-white transition">+91-612-225-4500</a>
              </p>
            </div>

            <div className="bg-white/10 p-8 rounded-lg text-center">
              <div className="text-4xl mb-4">✉️</div>
              <h3 className="text-xl font-bold mb-2">Email</h3>
              <p className="text-white/80">
                <a href="mailto:info@hotelfortune.com" className="hover:text-white transition">info@hotelfortune.com</a><br />
                <a href="mailto:reservations@hotelfortune.com" className="hover:text-white transition">reservations@hotelfortune.com</a>
              </p>
            </div>
          </div>

          <div className="bg-white/10 p-8 md:p-12 rounded-lg">
            <h3 className="text-2xl font-bold mb-6">Send us a Message</h3>
            <form className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  className="bg-white/20 border border-white/30 rounded-lg px-4 py-3 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white"
                />
                <input
                  type="email"
                  placeholder="Your Email"
                  className="bg-white/20 border border-white/30 rounded-lg px-4 py-3 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white"
                />
              </div>
              <textarea
                placeholder="Your Message"
                rows={4}
                className="w-full bg-white/20 border border-white/30 rounded-lg px-4 py-3 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white"
              />
              <Button className="w-full md:w-auto bg-white text-primary hover:bg-secondary">
                Send Message
              </Button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-foreground text-white py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="text-xl font-bold mb-4">Hotel Fortune</h4>
              <p className="text-white/60">Your gateway to luxury hospitality in Patna</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-white/60">
                <li><a href="#rooms" className="hover:text-white transition">Rooms</a></li>
                <li><a href="#amenities" className="hover:text-white transition">Amenities</a></li>
                <li><a href="#gallery" className="hover:text-white transition">Gallery</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-white/60">
                <li><a href="#" className="hover:text-white transition">FAQ</a></li>
                <li><a href="#" className="hover:text-white transition">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition">Terms & Conditions</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Follow Us</h4>
              <div className="flex gap-4">
                <a href="#" className="hover:text-primary transition">Facebook</a>
                <a href="#" className="hover:text-primary transition">Instagram</a>
                <a href="#" className="hover:text-primary transition">Twitter</a>
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-8 text-center text-white/60">
            <p>&copy; 2024 Hotel Fortune Patna. All rights reserved. | Luxury Redefined</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
