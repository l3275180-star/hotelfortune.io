# Hotel Fortune, Patna - Luxury 5-Star Hotel Demo Website

A beautiful, fully-responsive demo website for Hotel Fortune, Patna. This project showcases a premium hotel brand with stunning visuals, smooth interactions, and mobile-first design.

## Features

✨ **Hero Section** - Eye-catching banner with hotel imagery and call-to-action
🛏️ **Room Showcase** - Display of 3 room categories (Deluxe, Executive, Presidential) with features and pricing
🎯 **Amenities Section** - 6 premium amenities with emoji icons and descriptions
🖼️ **Gallery** - Beautiful image gallery featuring:
   - Fine Dining Restaurant
   - Swimming Pool
   - Luxury Spa
   - Guest Rooms
⭐ **Guest Reviews** - 5-star testimonials from satisfied guests
📞 **Contact Section** - Address, phone, email with integrated contact form
📱 **Mobile Responsive** - Fully optimized for all device sizes with sticky navigation

## Design Highlights

- **Color Scheme**: Elegant gold/brown (#8B6F47) primary with cream backgrounds - evokes luxury and heritage
- **Typography**: Clean, readable fonts with proper hierarchy
- **Responsive Layout**: Works perfectly on mobile, tablet, and desktop
- **No Authentication Required** - Completely ready to view as a demo
- **Fast Loading** - Optimized images and modern Next.js performance

## Technology Stack

- **Framework**: Next.js 16 with React 19
- **Styling**: Tailwind CSS 3
- **UI Components**: shadcn/ui
- **Image Handling**: Next.js Image component for optimization
- **Icons**: Lucide React icons + emoji

## Key Sections

### 1. Navigation
- Sticky header with logo and navigation links
- Mobile hamburger menu that expands on tap
- Desktop menu with hover effects

### 2. Hero Section
- Full-screen background image
- Gradient overlay for text contrast
- Clear call-to-action button

### 3. About Section
- Hotel description and heritage
- 5-star luxury badges
- Side-by-side text and image layout

### 4. Room Cards (3 variants)
- High-quality room images
- Feature lists with checkmarks
- Price per night display
- "View Details" action buttons

### 5. Amenities Grid (6 items)
- Emoji icons for visual appeal
- Descriptive titles and text
- Hover effects

### 6. Image Gallery (2x2 grid)
- Responsive grid layout
- Image overlay with labels
- Hover zoom effect

### 7. Testimonials
- Star ratings
- Guest quotes
- Guest names and roles

### 8. Contact Section
- 3-column info cards (Address, Phone, Email)
- Contact form with name, email, message fields
- Styled form inputs

### 9. Footer
- Quick links
- Support links
- Social media links
- Copyright information

## Mobile Features

✅ Hamburger menu that toggles on mobile
✅ Single-column layouts on small screens
✅ Touch-friendly button sizes
✅ Readable text sizes
✅ Optimized images
✅ Proper spacing and padding

## Demo Content

All content is demo/placeholder data:
- Address: Ashoka Raj Path, Fraser Road, Patna, Bihar 800001
- Phone: +91-612-225-4567 / +91-612-225-4500
- Email: info@hotelfortune.com / reservations@hotelfortune.com
- Room prices: ₹8,500 - ₹18,000 per night
- Guest testimonials from fictional guests

## Running the Demo

The website is already running and ready to view:

```bash
npm run dev
# or
pnpm dev
```

Then open `http://localhost:3000` in your browser.

## No Sign-Up Required

This is a **fully public demo** - no authentication, no sign-up, no login required. Just open and explore!

## Customization

To customize for a real hotel:

1. **Update Contact Information** - Replace phone, email, and address in the Contact section
2. **Replace Images** - Add real hotel photos to `/public` folder
3. **Update Room Details** - Modify room types, prices, and features
4. **Customize Amenities** - Add/remove amenities and emoji icons
5. **Update Testimonials** - Add real guest reviews
6. **Change Colors** - Update theme colors in `globals.css`

## Files Structure

```
/app
  - page.tsx (Main hotel page)
  - layout.tsx (Root layout with metadata)
  - globals.css (Theme and styles)
/public
  - hotel-hero.png (Hero image)
  - deluxe-room.png (Room image)
  - restaurant.png (Dining image)
  - pool.png (Pool image)
  - spa.png (Spa image)
/components/ui
  - button.tsx (Reusable button)
  - Other shadcn components
```

## Performance

- ⚡ Optimized images with Next.js Image component
- 🚀 Server-side rendering with React Server Components
- 📦 Minimal JavaScript bundle
- ⏱️ Fast First Contentful Paint (FCP)

## Browser Support

- Modern browsers (Chrome, Firefox, Safari, Edge)
- Mobile browsers (iOS Safari, Chrome Mobile)
- Responsive design works on all screen sizes

## License

This demo is for educational and development purposes.

---

**Built with v0** - Ready to customize and deploy! 🎉
